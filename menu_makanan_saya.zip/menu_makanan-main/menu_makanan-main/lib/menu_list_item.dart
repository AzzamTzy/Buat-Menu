import 'package:flutter/material.dart';
import 'package:menu_makanan/detail_page.dart';
import 'package:menu_makanan/menu.dart';

class ItemShopList extends StatelessWidget {
  final Menu menu;

  const ItemShopList({super.key, required this.menu});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Column(
        children: [
          Container(
              padding: const EdgeInsets.all(24.0),
              child: InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return DetailPage(
                          menu: menu,
                        );
                      },
                    ),
                  );
                },
                child: ClipRRect(
                  borderRadius: const BorderRadius.all(Radius.circular(24.0)),
                  child: Image.asset(
                    menu.image,
                    width: double.infinity,
                    height: 200,
                    fit: BoxFit.cover,
                  ),
                ),
              )),
          Text(
            menu.title,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(
            "Price : ${menu.price}K",
            style: const TextStyle(color: Color.fromRGBO(112, 24, 0, 1)),
          )
        ],
      ),
    );
  }
}
