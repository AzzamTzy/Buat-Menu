import 'package:flutter/material.dart';
import 'package:menu_makanan/menu.dart';

class DetailPage extends StatelessWidget {
  final Menu menu;

  const DetailPage({super.key, required this.menu});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back),
        ),
        actions: [
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text("More Button")));
            },
            icon: const Icon(Icons.more_vert),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Image.asset(menu.image),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                OutlinedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Selectable Button")));
                  },
                  style: OutlinedButton.styleFrom(
                    //TODO : change the color
                    foregroundColor: const Color.fromARGB(255, 242, 72, 11),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  //TODO : change the text
                  child: const Text('Menu Only'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Selectable Button")));
                  },
                  style: OutlinedButton.styleFrom(
                    //TODO : change the color
                    foregroundColor: const Color.fromARGB(255, 242, 72, 11),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  //TODO : change the text
                  child: const Text('Lauk Tambahan'),
                ),
              ],
            ),
            Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.only(left: 16, top: 24, right: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      menu.title,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 24.0),
                    ),
                    Text(
                      "Price : ${menu.price}K",
                      style: const TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 24.0),
                    ),
                  ],
                )),
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 16),
              child: const Row(
                children: [
                  Text(
                    "Total item : ",
                    style: TextStyle(fontSize: 16.0),
                  ),
                  AddItem(),
                ],
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 16),
              child: const Row(
                children: [Text("Package Protection : "), SwitchButton()],
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 16),
              child: const Row(
                children: [
                  //TODO : change the text
                  Text("Add Cabai"),
                  CheckBox(),
                ],
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 16),
              child: const Row(
                children: [
                  //TODO : change the text
                  Text("Add Bag"),
                  CheckBox(),
                ],
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.only(left: 16, top: 16),
              child: const Text(
                "Description : ",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18.0),
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.all(16),
              child: Text(menu.description),
            ),
            Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Buy Button")));
                  },
                  style: ButtonStyle(
                    backgroundColor: WidgetStateProperty.all(
                      //TODO : change the color
                      const Color.fromRGBO(93, 169, 106, 1),
                    ),
                  ),
                  child: const Text(
                    "Buy Now",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text("FAQ Button")));
        },
        backgroundColor: const Color.fromARGB(255, 242, 72, 11),
        child: const Icon(Icons.call_rounded, color: Colors.white),
      ),
    );
  }
}

//implementation stateful widget
class SwitchButton extends StatefulWidget {
  const SwitchButton({super.key});

  @override
  State<SwitchButton> createState() => _SwitchButtonState();
}

class _SwitchButtonState extends State<SwitchButton> {
  bool _isSwitched = false;

  @override
  Widget build(BuildContext context) {
    return Switch(
      value: _isSwitched,
      onChanged: (value) {
        setState(
          () {
            _isSwitched = value;
          },
        );
      },
      //TODO : change the color
      activeTrackColor: const Color.fromRGBO(52, 88, 94, 1),
      inactiveTrackColor: const Color.fromRGBO(93, 169, 106, 0.5),
    );
  }
}

class CheckBox extends StatefulWidget {
  const CheckBox({super.key});

  @override
  State<CheckBox> createState() => _CheckBoxState();
}

class _CheckBoxState extends State<CheckBox> {
  bool _isChecked = false;

  @override
  Widget build(BuildContext context) {
    return Checkbox(
      value: _isChecked,
      onChanged: (value) {
        setState(() {
          _isChecked = value!;
        });
      },
      //TODO : change the color
      activeColor: const Color.fromRGBO(52, 88, 94, 1),
    );
  }
}

class AddItem extends StatefulWidget {
  const AddItem({super.key});

  @override
  State<AddItem> createState() => _AddItemState();
}

class _AddItemState extends State<AddItem> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  void _decreasedCounter() {
    setState(() {
      _counter-- >= 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(onPressed: _incrementCounter, icon: const Icon(Icons.add)),
        Text(
          '$_counter',
        ),
        IconButton(
            onPressed: _decreasedCounter, icon: const Icon(Icons.remove)),
      ],
    );
  }
}
