class Menu {
  final String image;
  final String title;
  final double price;
  final String description;

  Menu(this.image, this.title, this.price, this.description);
}

//TODO : change the assets path
//TODO : change value(title, price, description)
List<Menu> menus = [
  Menu("assets/images/pizza.jpg", "Pizza", 130.000,
      "Piza[1] (bahasa Italia: pizza) adalah hidangan gurih asal Italia sejenis adonan bundar dan pipih, yang dipanggang di oven dan biasanya dilumuri saus tomat serta keju dengan bahan makanan tambahan lainnya yang bisa dipilih sesuai selera. Keju yang dipakai biasanya mozzarella atau keju piza, bisa juga parmesan dan beberapa jenis keju lainnya."),
  Menu("assets/images/nasigoreng.jpg", "Nasi Goreng", 15.000,
      "Nasi goreng merupakan sajian nasi yang digoreng dalam sebuah wajan atau penggorengan yang menghasilkan cita rasa berbeda karena dicampur dengan bumbu-bumbu seperti garam, bawang putih, bawang merah, merica, rempah-rempah tertentu dan kecap manis. Selain itu, ditambahkan bahan-bahan pelengkap seperti telur, sayur-sayuran, makanan laut, atau daging. Makanan tersebut sering kali disantap sendiri atau disertai dengan hidangan lainnya. Nasi goreng adalah komponen populer dari masakan Asia Timur"),
  Menu("assets/images/kupattahu.jpg", "Kupat Tahu", 12.000,
      "Kupat tahu adalah makanan tradisional Indonesia yang berbahan dasar ketupat, tahu, kol, dan tauge yang telah digoreng, dicampur dengan bumbu kacang dan kecap. Sebagai alternatif, lontong dapat juga digunakan sebagai pengganti ketupat. Ada banyak jenis kupat tahu, tetapi yang terkenal ialah yang berasal dari Singaparna, Surakarta, dan Grabag yang masing-masing memiliki perbedaan pada bumbu dan pelengkap. Pada versi Magelang dan Solo, terdapat irisan kol, bakwan, mi, dan tahu putih, sementara pada versi Singaparna, terdapat tauge yang telah direbus."),
  Menu("assets/images/kopihitam.jpg", "Kopi Hitam", 5.000,
      "Kopi hitam tidak mengandung gula, susu, atau krimer. Rasa kopi hitam yang khas berasal dari kandungan kafein, asam, dan antioksidan yang ada di dalam biji kopi."),
  Menu("assets/images/satekambing.jpg", "Sate Kambing", 15.000,
      "Sate kambing adalah sejenis makanan sate terbuat dari daging kambing. daging kambing tersebut disate (ditusuk dengan bambu yang dibentuk seperti lidi yang agak besar) dan dibumbui dengan rempah-rempah dan bumbu dapur, kemudian dibakar. Penyajiannya disajikan bersama lalapan kubis, tomat, dan bawang merah yang diiris tipis kemudian diberi kecap dan ditambahkan taburan merica."),
  Menu("assets/images/sateayam.jpg", "Sate Ayam", 10.000,
      "Sate ayam adalah makanan khas Indonesia. Sate ayam dibuat dari daging ayam. Pada umumnya sate ayam dimasak dengan cara dipanggang menggunakan arang dan disajikan dengan pilihan bumbu kacang atau bumbu kecap. Sate ini biasanya disajikan bersama dengan lontong atau nasi. Sate ayam adalah makanan khas Madura, Jawa Timur."),
  Menu("assets/images/satesapi.jpg", "Sate Sapi", 25.000,
      "Sate (bahasa Jawa: ꦱꦠꦺ, translit. sate, KBBI: satai)[9][10] adalah makanan yang terbuat dari daging yang dipotong kecil-kecil dan ditusuk sedemikian rupa dengan tusukan lidi tulang daun kelapa atau bambu, kemudian dipanggang menggunakan bara arang kayu. Sate disajikan dengan berbagai macam bumbu yang bergantung pada variasi resep sate.[11] Daging yang dijadikan sate antara lain daging ayam, kambing, domba, sapi, babi, kelinci, kuda, dan lain-lain."),
  Menu("assets/images/kentanggoreng.jpg", "Kentang Goreng", 17.000,
      "Kentang goreng adalah hidangan yang dibuat dari potongan-potongan kentang yang digoreng dalam minyak goreng panas. Di dalam menu rumah-rumah makan, kentang goreng yang dipotong panjang-panjang dan digoreng dalam keadaan terendam di dalam minyak goreng panas disebut french fries."),
  Menu("assets/images/gulai.jpg", "Gulai Ayam", 30.000,
      "Gulai alias Gule adalah Masakan Indonesia berbahan baku daging ayam, aneka ikan, kambing, sapi, jeroan, atau sayuran seperti nangka muda dan daun singkong, yang diolah dalam kuah bumbu rempah yang bercita rasa gurih yang berasal dari Sumatra, Indonesia."),
];
