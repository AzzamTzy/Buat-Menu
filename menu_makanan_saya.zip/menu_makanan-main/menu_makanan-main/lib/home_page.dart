import 'package:flutter/material.dart';
import 'package:menu_makanan/menu.dart';
import 'package:menu_makanan/menu_list_item.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        //TODO : change the color
        backgroundColor: const Color.fromARGB(255, 242, 72, 11),
        title: const Text(
          "Menu Makanan",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        actions: [
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(const SnackBar(content: Text("Search Button")));
            },
            icon: const Icon(
              Icons.bookmark_outline,
              color: Colors.white,
            ),
          ),
          IconButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                content: Text("Bookmark Button"),
              ));
            },
            icon: const Icon(Icons.shopping_bag_outlined, color: Colors.white),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          switch (constraints.maxWidth) {
            case <= 620:
              return ListView.builder(
                itemCount: menus.length,
                itemBuilder: (context, index) {
                  final data = menus[index];
                  return ItemShopList(menu: data);
                },
              );
            case <= 905:
              return GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, crossAxisSpacing: 30.0),
                itemCount: menus.length,
                itemBuilder: (context, index) {
                  final data = menus[index];
                  return ItemShopList(menu: data);
                },
              );
            case <= 900:
              return GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, crossAxisSpacing: 30.0),
                itemCount: menus.length,
                itemBuilder: (context, index) {
                  final data = menus[index];
                  return ItemShopList(menu: data);
                },
              );
            default:
              return GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3),
                itemCount: menus.length,
                itemBuilder: (context, index) {
                  final data = menus[index];
                  return ItemShopList(menu: data);
                },
              );
          }
        },
      ),
    );
  }
}
